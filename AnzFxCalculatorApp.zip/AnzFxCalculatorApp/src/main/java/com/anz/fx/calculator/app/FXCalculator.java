package com.anz.fx.calculator.app;

import java.math.BigDecimal;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import com.anz.fx.calculator.app.constant.FxCalculatorConstant;
import com.anz.fx.calculator.app.exception.ExceptionHandler;
import com.anz.fx.calculator.app.exception.FxException;
import com.anz.fx.calculator.app.util.FXCalculatorUtil;

/**
 * This class contains main methods which takes in argument from command prompt and calculate currency details with the specified rate.
 * @Operations: main
 * @Developer: Sreenivasulu, Somagowni 
 */
public class FXCalculator {
	
	private static final Logger LOG = Logger.getLogger(FXCalculator.class.getName());
	 /**
	  * Entry point for this application. When user specified input in correct format, this method calculates the rates in intended currency. 
	  * @Input - args
	  * @Response - only print the details to user.
	  * @Exception - FXException
	*/
    public static void main( String[] args ) throws FxException{
    	 if(LOG.isLoggable(Level.INFO)){
    		 LOG.info("App->main()-> Input String length is : "+args.length);
    	 }
    	 /* 
    	  * Check if the input provided by user is correct and in specified format 
    	  * The correct format is : <ccy1> <amount1> in <ccy2> i.e AUD 100.00 in USD
    	*/
    	 if(args.length > 0 && args.length == FxCalculatorConstant.INPUT_ARGUMENT_LENGTH 
    			 			&& args[0]!= null && !args[0].equals("") 
    			 			&& args[1]!= null && !args[1].equals("")
    			 			&& NumberUtils.isNumber(args[1].replaceAll(",", "")) //Removing all the comma separated value before checking for number
    			 			&& args[2]!= null && !args[2].equals("")
    			 			&& args[2].equalsIgnoreCase(FxCalculatorConstant.INPUT_ARGUMENT_STRING) //This checks if input 3rd argument is "in" or not.
    			 			&& args[3]!= null && !args[3].equals("")){
    		if(FXCalculatorUtil.isCurrencyAvailable(args[0].toUpperCase()) && FXCalculatorUtil.isCurrencyAvailable(args[3].toUpperCase())){
		    	try{
		    		/*
		    		 * Initializing BigDecimal variable to zero which will be used for storing currency conversion value. 
		    		*/
	    			BigDecimal result =  BigDecimal.ZERO;
	    			/*
	    			 * Calculate the rate of given currency to the intended currency. 
	    			 * Just to make sure currency input is provided in upper case so that back end system does not fail. 
	    			 * */
		    		result = FXCalculatorUtil.calculateCurrencyValue(args[0].toUpperCase(), args[1], args[3].toUpperCase());
		    		/*
		    		 * Display back the calculated currency value to user. 
		    		*/
		    		System.out.println((args[0]+" "+args[1]+" = "+args[3]+" "+result));
		    	}catch(FxException ex){
		    		throw ExceptionHandler.generateException(ex.getMessage(), ex.getDetailedMessage(), ex.getSystem());
		    	}catch(Exception ex){
		    		throw ExceptionHandler.generateException(ex);
		    	}
    		}else {
    			/* 
    	    	  * Currency provided by user if does not exists then prompt this message to user console
    	    	*/
    			System.out.println(("Unable to find rate for "+args[0]+"/"+args[3]));
    		}
    	}else {
    		/*
    		 * Display back the error message to user if input provided does not match to the expected input. 
    		*/
    		System.out.println(("Invalid input arguments provided. Please provide input only in format : <ccy1> <amount1> in <ccy2>"));
    	}
    }
}
