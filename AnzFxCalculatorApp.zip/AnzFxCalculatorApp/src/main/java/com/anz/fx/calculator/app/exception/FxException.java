package com.anz.fx.calculator.app.exception;

/**
 * This class is custom exception class for FX Calculator Application
 * @Developer: Sreenivasulu, Somagowni 
 */

public class FxException extends Exception{

	private static final long serialVersionUID = 1892734659900012900L;

	private String message;
	private String detailedMessage;
	private String system;
	
	public FxException(){
		
	}
	
	public FxException(String message, String detailedMessage,String system) {
		super();
		this.message = message;
		this.detailedMessage = detailedMessage;
		this.system = system;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDetailedMessage() {
		return detailedMessage;
	}
	public void setDetailedMessage(String detailedMessage) {
		this.detailedMessage = detailedMessage;
	}
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
}
