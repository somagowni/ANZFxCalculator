package com.anz.fx.calculator.app.exception;

import com.anz.fx.calculator.app.constant.FxCalculatorConstant;


/**
 * This class contains all the logic for generating exception response to be sent back to user/application
 * @Operations: generateException
 * @Developer: Sreenivasulu, Somagowni 
 */
public final class ExceptionHandler {
	
	/**
	 * The private constructor for not to allow creation of object for this class
	 */
	private ExceptionHandler() {		
	}
	
	/**
	 * This class contains all the logic for generating exception response to be sent
	 * @Input: message, detailedMessage, system
	 * @Output: FxException
	 * @Exception: none
	 */
	public static FxException generateException(String message, String detailedMessage, String system){
		FxException exception = new FxException(system, system, system);
		exception.setMessage(message);
		exception.setSystem(system);
		exception.setDetailedMessage(detailedMessage);
		return exception;
	}
	/**
	 * This class contains all the logic for generating exception response to be sent
	 * @Input: Exception
	 * @Output: FxException
	 * @Exception: none
	 */
	 public static FxException generateException(Exception ex) {
		 	FxException exception = new FxException(FxCalculatorConstant.EXCEPTION_GENERIC_MESSAGE, ex.getMessage(), FxCalculatorConstant.EXCEPTION_SYSTEM);
	        return exception;
	    }

}
