package com.anz.fx.calculator.app;

import java.math.BigDecimal;
import java.util.HashMap;
import org.junit.Test;
import org.junit.Rule;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.rules.ExpectedException;

import com.anz.fx.calculator.app.FXCalculator;
import com.anz.fx.calculator.app.exception.FxException;
import com.anz.fx.calculator.app.util.FXCalculatorUtil;
import com.anz.fx.calculator.app.util.LoadProperty;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * This class contains test cases for ANZ FX Calculator Application.
 * @Developer: Sreenivasulu, Somagowni 
 */
public class FxCalculatorTest extends TestCase
{
    public FxCalculatorTest( String testName )
    {
        super( testName );
    }
 
    // Test for convertStringToBigDecimal Method 
    
    @Test
    public void testConvertStringToBigDecimal()throws FxException {
    	BigDecimal big = FXCalculatorUtil.convertStringToBigDecimal("100.25");
    	double d = big.doubleValue();
       assertEquals(100.25, d , 0.0);
    }
    @Test
     public void testConvertStringToBigDecimalWithNegativeInput() throws FxException{
    	BigDecimal big = FXCalculatorUtil.convertStringToBigDecimal("-100.25");
    	double d = big.doubleValue();
    	assertNotSame(100.25, d);
    }
    @Test
    public void testConvertStringToBigDecimalWithInvalidInput() throws FxException{
    	BigDecimal big = FXCalculatorUtil.convertStringToBigDecimal("100,00");
    	double d = big.doubleValue();
    	assertNotSame(10000, d);
   }
    @Test
    public void testConvertStringToBigDecimalWithNull() throws FxException {
    	try{
    		BigDecimal big = FXCalculatorUtil.convertStringToBigDecimal("");
    		fail("Input field provided is not valid ");
    	}catch (FxException e) {
    		assertThat(e.getMessage(), is("Input field provided is not valid "));
        }
    }
    
    // Test for calculateCurrencyValue Method
    
    @Test
    public void testCalculateCurrencyValue() throws FxException{
    	BigDecimal big = FXCalculatorUtil.calculateCurrencyValue("AUD", "100", "CAD");
    	assertEquals(96.09, big.doubleValue() , 0.0);
    }
    @Test
    public void testCalculateCurrencyValueSimilarCurrency() throws FxException{
    	BigDecimal big = FXCalculatorUtil.calculateCurrencyValue("AUD", "100", "AUD");
    	assertEquals(100, big.doubleValue() , 0.0);
    }
    @Test
    public void testCalculateCurrencyValueWithNotNull() throws FxException{
    	BigDecimal big = FXCalculatorUtil.calculateCurrencyValue("AUD", "100", "DKK");
    	assertEquals(505.76, big.doubleValue() , 0.0);
    }
    @Test
    public void testCalculateCurrencyValueWithCrossReference() throws FxException{
    	BigDecimal big = FXCalculatorUtil.calculateCurrencyValue("NOK", "100", "JPY");
    	assertEquals(1704, big.doubleValue() , 0.0);
    }
    @Test
    public void testCalculateCurrencyValueExceptionWithNegativeArgs() throws FxException{
    	BigDecimal big = FXCalculatorUtil.calculateCurrencyValue("NOK", "-100", "JPY");
    	assertEquals(-1704, big.doubleValue() , 0.0);
    }
    @Test
    public void testCalculateCurrencyValueExceptionWithNull() throws FxException {
    	try{
    		BigDecimal big = FXCalculatorUtil.calculateCurrencyValue("NOK", "100","");
    		fail("Input field provided is not valid ");
    	}catch (FxException e) {
    		assertThat(e.getMessage(), is("Input field provided is not valid "));
        }
    }
    @Test
    public void testCalculateCurrencyValueExceptionWithAllNullArgs() throws FxException {
    	try{
    		BigDecimal big = FXCalculatorUtil.calculateCurrencyValue("", "","");
    		fail("Input field provided is not valid ");
    	}catch (FxException e) {
    		assertThat(e.getMessage(), is("Input field provided is not valid "));
        }
    }
    @Test
    public void testCalculateCurrencyValueExceptionWithInvalidArgs() throws FxException{
    	try{
    		BigDecimal big = FXCalculatorUtil.calculateCurrencyValue("NOK", "100","100");
    		fail("Currency details are not found in currency matrix table");
    	}catch (FxException e) {
    		assertThat(e.getMessage(), is("Currency details are not found in currency matrix table"));
        }
    }
    
    // Test for IsCurrencyAvailable Method
    
    @Test
    public void testIsCurrencyAvailable() throws FxException{
    	boolean flag = FXCalculatorUtil.isCurrencyAvailable("AUD");
    	assertTrue(flag);
    	assertNotNull(flag);
    }
    @Test
    public void testIsCurrencyAvailableWithException() throws FxException{
    	try{
    		boolean flag = FXCalculatorUtil.isCurrencyAvailable("");
    		fail("Input field provided is not valid ");
    	}catch (FxException e) {
    		assertThat(e.getMessage(), is("Input field provided is not valid "));
        }
    }
    @Test
    public void testIsCurrencyAvailableWithInvalidArgs() throws FxException{
    	boolean flag = FXCalculatorUtil.isCurrencyAvailable("WSD");
    	assertNull(null);
    }
    @Test
    public void testIsCurrencyAvailableWithNull() throws FxException{
    	boolean flag = FXCalculatorUtil.isCurrencyAvailable(" ");
    	assertFalse(flag);
    	assertNotNull(flag);
    }
    
 // Test for getFXPropValue Method
    
    @Test
    public void testGetFXPropValue() throws FxException{
    	HashMap<String, String> map = LoadProperty.getFXPropValue();
    	assertNotNull(map);
    	String value = null;
    	if(map.containsKey("AUDUSD")){
    		 value = map.get("AUDUSD");
    	}
    	assertEquals("D", value);
    }
    @Test
    public void testGetFXPropValueWithNull() throws FxException{
    	HashMap<String, String> map = LoadProperty.getFXPropValue();
    	assertNotNull(map);
    	String value = null;
    	String key ="";
    	if(map.containsKey(key)){
    		 value = map.get("AUDUSD");
    	}
    	assertEquals(null, value);
    }
    
    @Test 
    public void testValidateThatGetFXPropValueWorks() throws FxException {
    	HashMap<String, String> map = LoadProperty.getFXPropValue();
    	assertNotNull(map);
    }

 // Test for main Method
    
    @Test
    public void testCurrencyCalculatorMainApp() throws FxException{
    	String[] args = { "AUD", "100", "in", "CAD" };
    	FXCalculator.main(args);
    }
    @Test
    public void testCurrencyCalculatorMainAppWithInvalidInput() throws FxException{
    	String[] args = { "AUD", "AUD", "in", "CAD" };
    	try{
    		FXCalculator.main(args);
    		//fail("Invalid input arguments provided. Please provide input only in format : <ccy1> <amount1> in <ccy2>");
    	}catch (FxException e) {
    		assertThat(e.getMessage(), is("Invalid input arguments provided. Please provide input only in format : <ccy1> <amount1> in <ccy2>"));
        }
    }
    @Test
    public void testCurrencyCalculatorMainAppWithNull() throws FxException{
    	String[] args = { "AUD", "100", "in", "" };
    	try{
    		FXCalculator.main(args);
    		//fail("Invalid input arguments provided. Please provide input only in format : <ccy1> <amount1> in <ccy2>");
    	}catch (FxException e) {
    		assertThat(e.getMessage(), is("Invalid input arguments provided. Please provide input only in format : <ccy1> <amount1> in <ccy2>"));
        }
    }
    @Test
    public void testCurrencyCalculatorMainAppWithException() throws FxException{
    	String[] args = { "AUD", "100", "in"};
    	try{
    		FXCalculator.main(args);
    		//fail("Invalid input arguments provided. Please provide input only in format : <ccy1> <amount1> in <ccy2>");
    	}catch (FxException e) {
    		assertThat(e.getMessage(), is("Invalid input arguments provided. Please provide input only in format : <ccy1> <amount1> in <ccy2>"));
        }
    }

    //Test cases for getDecimalPlace method
    
    @Test
    public void testGetFXRates() throws FxException{
    		double rate = FXCalculatorUtil.getFXRates("AUDUSD");
    		assertEquals(0.8371, rate);
    	
    }
    @Test
    public void testGetFXRatesWithSpaces() throws FxException{
    		double rate = FXCalculatorUtil.getFXRates("CADUSD ");
    		assertEquals(0.8711, rate);
    	
    }
    @Test
    public void testGetFXRatesWithoutCurrencyMatch() throws FxException{
    		double rate = FXCalculatorUtil.getFXRates("DKKUSD");
    		assertEquals(0.0, rate);
    		assertNotSame(100.25, rate);
    	
    }
    @Test
    public void testGetFXRatesWithException() throws FxException {
    	try{
    		double rate = FXCalculatorUtil.getFXRates("");
    		fail("Input field provided is not valid ");
    	}catch (FxException e) {
    		assertThat(e.getMessage(), is("Input field provided is not valid "));
        }
    }
    
   //Test cases for getDecimalPlace method
    
    @Test
    public void testGetDecimalPlace() throws FxException{
    		int decimalPlace = FXCalculatorUtil.getDecimalPlace("AUD");
    		assertEquals(2, decimalPlace);
    	
    }
    @Test
    public void testGetDecimalPlaceWithInvalidInput() throws FxException{
    		int decimalPlace = FXCalculatorUtil.getDecimalPlace("JPY ");
    		assertEquals(0, decimalPlace);
    	
    }
    @Test
    public void testGetDecimalPlaceWithoutMatch() throws FxException{
    		int decimalPlace = FXCalculatorUtil.getDecimalPlace("DKKUSD");
    		assertEquals(10, decimalPlace);
    	
    }
    @Test
    public void testGetDecimalPlaceWithException() throws FxException {
    	try{
    		int rate = FXCalculatorUtil.getDecimalPlace("");
    		fail("Input field provided is not valid ");
    	}catch (FxException e) {
    		assertThat(e.getMessage(), is("Input field provided is not valid "));
        }
    }
    
  //Test cases for fetchCrossCurrencyValue method
    
    @Test
    public void testFetchCrossCurrencyValue() throws FxException{
    		String key = FXCalculatorUtil.fetchCrossCurrencyValue("AUD","USD");
    		assertEquals("D", key);
    	
    }
    @Test
    public void testFetchCrossCurrencyValueWithUnity() throws FxException{
    		String key = FXCalculatorUtil.fetchCrossCurrencyValue("CAD","CAD");
    		assertEquals("U", key);
    	
    }
    @Test
    public void testFetchCrossCurrencyValueWithInversion() throws FxException{
    		String key = FXCalculatorUtil.fetchCrossCurrencyValue("DKK","EUR");
    		assertEquals("I", key);
    	
    }
    @Test
    public void testFetchCrossCurrencyValueWithoutMatch() throws FxException{
    		String key = FXCalculatorUtil.fetchCrossCurrencyValue("DKK","WSD");
    		assertEquals(null, key);
    	
    }
    @Test
    public void testFetchCrossCurrencyValueWithException() throws FxException {
    	try{
    		String key = FXCalculatorUtil.fetchCrossCurrencyValue("","");
    		fail("Input field provided is not valid ");
    	}catch (FxException e) {
    		assertThat(e.getMessage(), is("Input field provided is not valid "));
        }
    }
    
//Test cases for calculateRateFromCrossCurrency method
    
    @Test
    public void testCalculateRateFromCrossCurrency() throws FxException{
    	BigDecimal finalFXResult = BigDecimal.ZERO;
    	finalFXResult = FXCalculatorUtil.calculateRateFromCrossCurrency("GBP","JPY", "100","USD");
    	assertEquals(18811.75850658, finalFXResult.doubleValue());
    	
    }
    @Test
    public void testCalculateRateFromCrossCurrencyWithValidInput() throws FxException{
    	BigDecimal finalFXResult = BigDecimal.ZERO;
    	finalFXResult = FXCalculatorUtil.calculateRateFromCrossCurrency("NOK","USD", "100","EUR");
    	assertEquals(14.2121845, finalFXResult.doubleValue());
    	
    }
    @Test
    public void testCalculateRateFromCrossCurrencyWithDirectCrossRef() throws FxException{
    	BigDecimal finalFXResult = BigDecimal.ZERO;
    	finalFXResult =  FXCalculatorUtil.calculateRateFromCrossCurrency("DKK","GBP", "100","USD");
    	assertEquals(10.55366131, finalFXResult.doubleValue());
    	
    }
    @Test
    public void testCalculateRateFromCrossCurrencyWithInvalidArgs() throws FxException{
    	try{
    		BigDecimal finalFXResult = BigDecimal.ZERO;
    		finalFXResult =  FXCalculatorUtil.calculateRateFromCrossCurrency("NOK","JPY", "100","");
    		fail("Input field provided is not valid ");
    	}catch (FxException e) {
    		assertThat(e.getMessage(), is("Input field provided is not valid "));
        }    	
    }
    @Test
    public void testCalculateRateFromCrossCurrencyWithException() throws FxException {
    	try{
    		BigDecimal finalFXResult = BigDecimal.ZERO;
        	finalFXResult = FXCalculatorUtil.calculateRateFromCrossCurrency("","", "","");
    		fail("Input field provided is not valid ");
    	}catch (FxException e) {
    		assertThat(e.getMessage(), is("Input field provided is not valid "));
        }
    }
 
    //Test cases for calculateRateByCrossCurrency method
    
    @Test
    public void testCalculateRateByCrossCurrency() throws FxException{
    	BigDecimal finalFXResult = BigDecimal.ZERO;
    	finalFXResult = FXCalculatorUtil.calculateRateByCrossCurrency("EUR","AUD","USD");
    	assertEquals(1.4711504002, finalFXResult.doubleValue());
    	
    }
    @Test
    public void testCalculateRateByCrossCurrencyWithCrossRef() throws FxException{
    	BigDecimal finalFXResult = BigDecimal.ZERO;
    	finalFXResult =  FXCalculatorUtil.calculateRateByCrossCurrency("CNY","ANZ","USD");
    	assertEquals(0.0, finalFXResult.doubleValue());
    	
    }
    @Test
    public void testCalculateRateByCrossCurrencyWithDifferentCrossRefVal() throws FxException{
    	BigDecimal finalFXResult = BigDecimal.ZERO;
    	finalFXResult =  FXCalculatorUtil.calculateRateByCrossCurrency("CZK","USD","EUR");
    	assertEquals(0.044615039, finalFXResult.doubleValue());
    	
    }
    @Test
    public void testCalculateRateByCrossCurrencyWithUnity() throws FxException{
    	BigDecimal finalFXResult = BigDecimal.ZERO;
    	finalFXResult = FXCalculatorUtil.calculateRateByCrossCurrency("AUD","AUD","U");
    	assertEquals(0.0, finalFXResult.doubleValue());
    	
    }
    @Test
    public void testCalculateRateByCrossCurrencyWithDirect() throws FxException{
    	BigDecimal finalFXResult = BigDecimal.ZERO;
    	finalFXResult = FXCalculatorUtil.calculateRateByCrossCurrency("GBP","USD","D");
    	assertEquals(1.5683, finalFXResult.doubleValue());
    	
    }
    @Test
    public void testCalculateRateByCrossCurrencyWithInversion() throws FxException{
    	BigDecimal finalFXResult = BigDecimal.ZERO;
    	finalFXResult = FXCalculatorUtil.calculateRateByCrossCurrency("NOK","EUR","I");
    	assertEquals(0.1154054771, finalFXResult.doubleValue());
    	
    }
    @Test
    public void testCalculateRateByCrossCurrencyWithException() throws FxException {
    	try{
    		BigDecimal finalFXResult = BigDecimal.ZERO;
        	finalFXResult =  FXCalculatorUtil.calculateRateByCrossCurrency("","","");
    		fail("Input field provided is not valid ");
    	}catch (FxException e) {
    		assertThat(e.getMessage(), is("Input field provided is not valid "));
        }
    }
}
